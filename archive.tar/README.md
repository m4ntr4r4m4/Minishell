# Minishell

watch this video https://www.youtube.com/watch?v=8Hx5Ye_mf8A&list=PLKUb7MEve0Tizh0gqRm8s8IJiPg5VC4mO
allokey




### Don't forget to protect against losing the env vars with <env -i ./minishell> cmd   ###



#### treat this case for exec  cat a & echo "bomm bom"   ######


### treat this case  cat <<EOF
This is a test
EOF  ####


| task | Mantra    | Jaime    |
| :---:   | :---: | :---: |
| Seconds | 301   | 283   |
